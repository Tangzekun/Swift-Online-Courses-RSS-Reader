//
//  Article.swift
//  RSSReader
//
//  Created by TangZekun on 1/1/16.
//  Copyright © 2016 TangZekun. All rights reserved.
//

struct Article
{
    var title = ""
    var imageUrl = ""
    var url = ""
}

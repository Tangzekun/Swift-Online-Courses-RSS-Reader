//
//  ArticleCell.swift
//  RSSReader
//
//  Created by TangZekun on 1/1/16.
//  Copyright © 2016 TangZekun. All rights reserved.
//

import UIKit

class ArticleCell: UICollectionViewCell
{
    @IBOutlet weak var imageView: UIImageView!    
    @IBOutlet weak var titleLabel: UILabel!
    
}

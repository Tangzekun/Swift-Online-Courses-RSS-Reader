//
//  DetailViewController.swift
//  RSSReader
//
//  Created by TangZekun on 1/1/16.
//  Copyright © 2016 TangZekun. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    
    
    @IBOutlet weak var webView: UIWebView!
    
    var currentArticle : Article?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let url = NSURL(string: currentArticle!.url)
        let request = NSURLRequest(URL: url!)
        webView.loadRequest(request)
        

    }

    

}

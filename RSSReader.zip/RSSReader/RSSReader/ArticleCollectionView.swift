//
//  ArticleCollectionView.swift
//  RSSReader
//
//  Created by TangZekun on 1/1/16.
//  Copyright © 2016 TangZekun. All rights reserved.
//

import UIKit

private let reuseIdentifier = "articleCell"

class ArticleCollectionView: UICollectionViewController
{
    
    var articles = [Article]()
    var xmlParser : NSXMLParser!
    var currentArticle = Article()
    var parsedElement = ""
    var currentImageUrl = ""

    override func viewDidLoad() {
        super.viewDidLoad()

        let urlString = NSURL(string: "http://techcrunch.com/feed/")
        
        let task = NSURLSession.sharedSession().dataTaskWithURL(urlString!)
        {
            (data,response,error) in
            if error != nil
            {
                return
                    print(error!.localizedDescription)
            }
            
            self.xmlParser = NSXMLParser (data: data!)
            self.xmlParser.delegate = self
            self.xmlParser.parse()
        }
        
        task.resume()


    }

    override func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        return 1
    }


    override func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return articles.count
    }

    override func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell
    {
        
        let article = articles[indexPath.row]
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier(reuseIdentifier, forIndexPath: indexPath) as! ArticleCell
        
        
        cell.titleLabel.text = article.title
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0))
        {
            if article.imageUrl.isEmpty
            {
                return
            }
            
            let imgUrl = NSURL(string : article.imageUrl)
            if imgUrl == nil
            {
                return
            }
            
            let imgData = NSData (contentsOfURL: imgUrl!)
            if imgData == nil
            {
                return
            }
            
            let currentImg = UIImage(data: imgData!)
            dispatch_async(dispatch_get_main_queue())
            {
                cell.imageView.image = currentImg
            }
            
        }
        
        
    
        return cell
    }

    
    
    override func viewWillTransitionToSize(size: CGSize, withTransitionCoordinator coordinator: UIViewControllerTransitionCoordinator)
    {
        super.viewWillTransitionToSize(size, withTransitionCoordinator: coordinator)
        let flowLayout = collectionView?.collectionViewLayout as! UICollectionViewFlowLayout
        flowLayout.invalidateLayout()
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?)
    {
        if segue.identifier == "showDetail"
        {
            let controller = segue.destinationViewController as! DetailViewController
            let indexPath = sender as! NSIndexPath
            controller.currentArticle = articles [indexPath.row]
        }
    }


}


extension ArticleCollectionView : NSXMLParserDelegate
{
    func parser(parser: NSXMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String])
        // parsed element
    {
        if elementName == "item"
        {
            currentArticle = Article()
            return
        }
        
        if elementName == "title"
        {
            parsedElement = "title"
        }
        
        if elementName == "link"
        {
            parsedElement = "link"
        }
        
        if elementName == "media:content"
        {
             currentImageUrl = attributeDict ["url"] as String!
        }
    }
    
    
    func parser(parser: NSXMLParser, foundCharacters string: String)
        // parsed Element (title) -> Techgranch is great
    {
        let str = string.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())
        
        if parsedElement == "title"
        {
            if currentArticle.title.isEmpty
            {
                currentArticle.title = str
            }
        }
        
        if parsedElement == "link"
        {
            if currentArticle.url.isEmpty
            {
                currentArticle.url = str
            }
        }
        
        
    }
    
    func parser(parser: NSXMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?)
        // current article
    {
        if elementName != "item"
        {
            return
        }
        
        currentArticle.imageUrl = currentImageUrl
        articles.append(currentArticle)
    }
    
    func parserDidEndDocument(parser: NSXMLParser)
    {
        dispatch_async(dispatch_get_main_queue())
        {
            self.collectionView!.reloadData()
        }
    }
}


extension ArticleCollectionView
{
    override func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath)
    {
        self.performSegueWithIdentifier("showDetail", sender: indexPath)

        
    }
}
